﻿using Microsoft.AspNetCore.Identity;

namespace PetHelp.Server.Models;
public class ApplicationUser : IdentityUser
{
}